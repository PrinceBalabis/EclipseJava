package labquiz;

import java.io.*;
import java.util.Random;

public class ChoiceBank {
	private Random random = new Random();
	private ChoiceQuestion[] questions;
	private int index = -1;

	public ChoiceBank(String filename) {
		try {
			String line, title, question, answer;
			String[] choices;
			FileInputStream fis = new FileInputStream(filename);
			InputStreamReader isr = new InputStreamReader(fis, "ISO-8859-1");
			BufferedReader br = new BufferedReader(isr);
			int nbrOfQuestions = Integer.parseInt(br.readLine());
			questions = new ChoiceQuestion[nbrOfQuestions];
			for(int i=0; i<questions.length; i++) {
				title = br.readLine();
				question = br.readLine();
				choices = br.readLine().split(";");
				answer = br.readLine();
				questions[i] = new ChoiceQuestion(title,question,choices,answer);
			}
			br.close();
		} catch (Exception e) {
			questions = new ChoiceQuestion[0];
		}
	}
	
	public ChoiceQuestion nextQuestion() {
		if (questions.length>0) {
			index++;
			if (index == questions.length)
				index = 0;
			return questions[index++];
		}
		return null;
	}

	public int nbrOfQuestions() {
		return questions.length;
	}

	public void randomizeQuestions() {
	    int swapPos;
	    ChoiceQuestion message;
	    for(int i=questions.length-1; i>0; i--) {
	        swapPos = random.nextInt(i+1);
	        message = questions[i];
	        questions[i] = questions[swapPos];
	        questions[swapPos] = message;
	    }
	}
}
