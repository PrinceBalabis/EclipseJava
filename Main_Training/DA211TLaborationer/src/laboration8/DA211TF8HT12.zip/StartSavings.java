package f8;

public class StartSavings {
    public static void main(String[] args) {
        Savings prog = new Savings();
        prog.save();
    }
}
