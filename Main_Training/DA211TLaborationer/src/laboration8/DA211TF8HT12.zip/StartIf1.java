package f8;

public class StartIf1 {
    public static void main(String[] args) {
        If1 prog = new If1();
        prog.ifSats1();
    }
}
