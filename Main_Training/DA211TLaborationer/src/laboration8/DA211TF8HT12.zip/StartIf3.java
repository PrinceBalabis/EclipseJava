package f8;

public class StartIf3 {
    public static void main(String args[]) {
        If3 prog = new If3();
        prog.liquorStore();
    }
}
