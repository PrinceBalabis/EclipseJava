package f8;

public class StartIf2 {
    public static void main(String[] args) {
        If2 prog = new If2();
        prog.price();
    }
}
