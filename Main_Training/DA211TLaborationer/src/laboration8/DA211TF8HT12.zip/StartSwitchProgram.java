package f8;

public class StartSwitchProgram {
    public static void main(String[] args) {
        SwitchProgram prog = new SwitchProgram();
        prog.switchEx();
    }
}
