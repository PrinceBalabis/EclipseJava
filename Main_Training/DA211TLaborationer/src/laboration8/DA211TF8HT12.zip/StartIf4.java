package f8;

public class StartIf4 {
    public static void main(String[] args) {
        If4 prog = new If4();
        prog.grade();
    }
}
