package laboration10;

/**
 * Träna do-while-loop
 * @author Rolf Axelsson
 */
public class Exercise10c {
    public void Exercise10c0() {
        int i = 0;
        do {
            System.out.print( 'A' + " ");
            i++;
        } while( i < 10 );
    }
    
    public static void main(String[] args) {
        Exercise10c e10c = new Exercise10c();
        e10c.Exercise10c0();
//        System.out.println();
//        e10c.Exercise10c1();
//        System.out.println();
//        e10c.Exercise10c2();
//        System.out.println();
//        e10c.Exercise10c3();
//        System.out.println();
//        e10c.Exercise10c4();
//        System.out.println();
//        e10c.Exercise10c5();
//        System.out.println();
//        e10c.Exercise10c6();
    }
}
