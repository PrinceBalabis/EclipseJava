package laboration10;

/**
 * Träna for-loop 
 * @author Rolf Axelsson
 */
public class Exercise10a {
    public void exercise10a0() {
        for( int i = 0 ; i < 10 ; i++ ) {
            System.out.print( 'A' + " ");
        }
    }

    public static void main(String[] args) {
        Exercise10a e10a = new Exercise10a();
        e10a.exercise10a0();
//        System.out.println();
//        e10a.exercise10a1();
//        System.out.println();
//        e10a.exercise10a2();
//        System.out.println();
//        e10a.exercise10a3();
//        System.out.println();
//        e10a.exercise10a4();
//        System.out.println();
//        e10a.exercise10a5();
//        System.out.println();
//        e10a.exercise10a6();
    }
}
