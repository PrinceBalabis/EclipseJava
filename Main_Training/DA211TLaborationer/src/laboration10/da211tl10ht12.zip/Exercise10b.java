package laboration10;

/**
 * Träna while-loop
 * @author Rolf Axelsson
 */
public class Exercise10b {
    public void exercise10b0() {
        int i = 0;
        while( i < 10 ) {
            System.out.print( 'A' + " ");
            i++;
        }
    }
    
    public static void main(String[] args) {
        Exercise10b e10b = new Exercise10b();
        e10b.exercise10b0();
//        System.out.println();
//        e10b.exercise10b1();
//        System.out.println();
//        e10b.exercise10b2();
//        System.out.println();
//        e10b.exercise10b3();
//        System.out.println();
//        e10b.exercise10b4();
//        System.out.println();
//        e10b.exercise10b5();
//        System.out.println();
//        e10b.exercise10b6();
    }
}
