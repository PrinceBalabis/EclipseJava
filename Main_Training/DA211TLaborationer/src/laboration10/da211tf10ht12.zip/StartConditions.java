package f10;

public class StartConditions {
	public static void main(String[] args) {
		Conditions prog = new Conditions();
		prog.testMethod();
	}
}
