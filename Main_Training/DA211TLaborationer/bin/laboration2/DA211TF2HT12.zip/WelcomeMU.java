import javax.swing.*;
import java.awt.*;

public class WelcomeMU {
    public void action() {
        JFrame frame = new JFrame("V�lkomsth�lsning");
        Container c = frame.getContentPane();
        JLabel text = new JLabel( "V�lkomna till MAH!!!", JLabel.CENTER );

        text.setFont( new Font( "SansSerif", Font.PLAIN, 36 ) );
        text.setForeground( Color.white );

        frame.setSize( 400, 300 );
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

        c.setLayout( new BorderLayout() );
        c.setBackground( Color.blue );
        c.add( text );

        frame.setVisible( true );
    }

    public static void main(String[] args) {
        WelcomeMU prog = new WelcomeMU();   // Ett objekt av typen WelcomeMU skapas
        prog.action();                      // Metoden action anropas i WelcomeMU-objektet
    }
}