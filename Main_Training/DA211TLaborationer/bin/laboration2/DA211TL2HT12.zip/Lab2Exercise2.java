﻿/*
 * Lab2Exercise2.java
 * Skapad den 3 september 2012
 */

/**
 * Programmet skriver text i Console-fönstret.
 * 
 * @author Rolf axelsson
 * @version 1.0
 */
public class Lab2Exercise2 {

    /*
     * Metoden gör 4 utskrifter i Console-fönstret.
     * Instruktionerna utförs uppifrån och ned.
     */
    public void calculation() {
        System.out.println("-   55");
        System.out.println("   311");
        System.out.println("   366");
        System.out.println("------");
    }

    /*
     * Instruktionerna i main-metoden utförs då programmet exekveras.
     * Instruktionerna utförs uppifrån och ned.
     */
    public static void main( String[] args ) {
        Lab2Exercise2 ex2 = new Lab2Exercise2();
        ex2.calculation();
    }
}
