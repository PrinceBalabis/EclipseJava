﻿package f11;

public class BookEx {
    public void ex() {
        Book book = new Book();
        book.init("Djup", "Henning Mankell", "9173430897");
        book.info();
    }

    public static void main(String[] args) {
        BookEx prog = new BookEx();
        prog.ex();
    }
}
