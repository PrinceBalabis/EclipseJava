﻿package f11;

public class Parameter {
    public void add(int nbr1, int nbr2) {
        int sum = nbr1+nbr2;
        System.out.println(nbr1 + "+" + nbr2 + "=" + sum);
    }
}
