﻿/*
 * TravelEx.java
 */
package f11;
import javax.swing.*;
/**
 * Programmet demonstrarar hur man anropar metoder i ett objekt
 * av typen TravelCosts.
 * @author Rolf Axelsson
 */
public class TravelEx {
	public void trip() {
        TravelCosts aTrip = new TravelCosts();
        String menu = "KOSTNADER\n\n1. Bensin\n2. Logi\n3. Mat\n" +
                "4. Övrigt\n5. Total kostnad\n0. Avslutan\n\n";
        int choice;
        double cost;
        
        choice = Integer.parseInt( JOptionPane.showInputDialog( menu ) );
        while( choice != 0 ) {
            switch( choice ) {
                case 1 :
                    cost = Double.parseDouble( JOptionPane.showInputDialog( "Ange kostnad för bensin" ) );
                    aTrip.buyPetrol( cost );
                    break;
                case 2 :
                    cost = Double.parseDouble( JOptionPane.showInputDialog( "Ange kostnad för logi" ) );
                    aTrip.buyLodging( cost );
                    break;
                case 3 :
                    cost = Double.parseDouble( JOptionPane.showInputDialog( "Ange kostnad för mat" ) );
                    aTrip.buyFood( cost );
                    break;
                case 4 :
                    cost = Double.parseDouble( JOptionPane.showInputDialog( "Ange kostnad för övrigt" ) );
                    aTrip.otherCosts( cost );
                    break;
                case 5 :
                	aTrip.travelInfo();
                    break;
            }
            choice = Integer.parseInt( JOptionPane.showInputDialog( menu ) );
        }
	}
    public static void main( String[] args ) {
        TravelEx prog = new TravelEx();
        prog.trip();
    }
}
