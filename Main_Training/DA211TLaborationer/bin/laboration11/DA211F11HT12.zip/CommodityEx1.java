﻿package f11;

public class CommodityEx1 {
    public void example() {
        Commodity enVara = new Commodity();
        enVara.setName("Pepparkakor");
        enVara.setPrice(22.50);
        enVara.setCategory("Bageri");
        enVara.info();
    }

    public static void main(String[] args) {
        CommodityEx1 prog = new CommodityEx1();
        prog.example();
    }
}
