package f11;
/**
 * Programmet visar att det går utmärkt att använda flera objekt av samma
 * typ (här Commodity-objekt) i ett program. Varje objekt har sitt eget minnesutrymme.
 * @author Rolf
 */
public class CommodityEx2 {
    public void action() {
        Commodity com1 = new Commodity ();
        Commodity com2 = new Commodity ();
        
        com1.setName("Bacon");
        com1.setCategory("Charkuteri");
        com1.setQuantity(100);
        com1.setPrice(10.95);
        
        com2.setName("Russin");
        com2.setCategory("Kolonial");
        com2.setQuantity(520);
        com2.setPrice(14.95);
        
        com1.info();
        com2.info();        
    }

    public static void main(String[] args) {
        CommodityEx2 prog = new CommodityEx2();
        prog.action();
    }
}