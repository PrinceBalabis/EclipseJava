﻿package f11;

public class ParameterEx {

    public void example() {
        Parameter param = new Parameter();
        int a = 23, b = 40;
        param.add(10, 20);
        param.add(15, 7);
        param.add(a, b);
    }

    public static void main(String[] args) {
        ParameterEx prog = new ParameterEx();
        prog.example();
    }
}
