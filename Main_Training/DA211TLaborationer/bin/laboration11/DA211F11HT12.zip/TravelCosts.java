/*
 * TravelCosts.java
 */
package f11;
import javax.swing.JOptionPane;
/**
 * En klass av typen TravelCosts lagrar kostnader under en resa. Klassen innehåller
 * metoder för att förenkla användningen av klassen.
 * @author Rolf Axelsson
 */
public class TravelCosts {
    private double petrol;
    private double lodging;
    private double food;
    private double otherCosts;
    
    public void buyPetrol( double cost ) {
    	this.petrol = this.petrol + cost;
    }
    
    public void buyLodging( double cost ) {
    	this.lodging = this.lodging + cost;
    }
    
    public void buyFood( double cost ) {
    	this.food += cost;
    }
    
    public void otherCosts( double cost ) {
    	this.otherCosts += cost;
    }
    
    public void travelInfo() {
        double total = this.petrol+ this.lodging + this.food + this.otherCosts;
        String message = "KOSTNADER PÅ RESA\n" + 
            String.format( "Bensin: %1.2f kr\n", this.petrol ) +
    	    String.format( "Logi:   %1.2f kr\n", this.lodging ) +
    	    String.format( "Mat:    %1.2f kr\n", this.food ) +
    	    String.format( "Övrigt: %1.2f kr\n", this.otherCosts ) +
    	    String.format( "TOTALT: %1.2f kr", total );
        JOptionPane.showMessageDialog(null,message);
    }
}

