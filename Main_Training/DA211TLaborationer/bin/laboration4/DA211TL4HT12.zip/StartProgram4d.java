package laboration4;

public class StartProgram4d {
    public static void main(String[] args) {
        Program4d p4d = new Program4d();
        p4d.nameAndJava();
    }
}
