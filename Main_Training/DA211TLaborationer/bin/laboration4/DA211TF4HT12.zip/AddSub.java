package f4;
import javax.swing.*;

public class AddSub {
    public void addSub() {
        int nbr1,nbr2;
        String str;
        int sum;

        str = JOptionPane.showInputDialog( "Ange tal 1");
        nbr1 = Integer.parseInt( str );
        str = JOptionPane.showInputDialog( "Ange tal 2");
        nbr2 = Integer.parseInt( str );

        sum = nbr1+nbr2;
        System.out.println(nbr1+"+"+nbr2+"="+sum);
        System.out.println(nbr2+"+"+nbr1+"="+(nbr2+nbr1));
        System.out.println(nbr1+"-"+nbr2+"="+(nbr1-nbr2));
        System.out.println(nbr2+"-"+nbr1+"="+(nbr2-nbr1));
    }
    
    public static void main(String[] args) {
        AddSub as = new AddSub();
        as.addSub();
	}
}
