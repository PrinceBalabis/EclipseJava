package f4;
import javax.swing.*;

public class BMI {
    public void bmiMethod() {
        int weight;
        double length,bmi;
        String str;
        
        str = JOptionPane.showInputDialog( "Ange din vikt (hela kg)" );
        weight = Integer.parseInt( str );
        length = Double.parseDouble( JOptionPane.showInputDialog( "Ange din längd (m)" ) );
        
        bmi = weight/(length*length);
        
        JOptionPane.showMessageDialog( null, "Ditt BodyMassIndex är "+bmi );
    }
}
