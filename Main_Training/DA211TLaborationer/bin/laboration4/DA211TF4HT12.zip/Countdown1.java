package f4;

public class Countdown1 {
	// -----------------------------------------------------------------
	// Prints two lines of output representing a rocket countdown.
	// -----------------------------------------------------------------
	public void countdown() {
		System.out.print("Three... ");
		System.out.print("Two... ");
		System.out.print("One... ");
		System.out.print("Zero... ");

		System.out.println("Liftoff!"); // appears on first output line

		System.out.println("Houston, we have a problem.");
	}
	
	public static void main(String[] args) {
		Countdown1 prog = new Countdown1();
		prog.countdown();
	}
}
