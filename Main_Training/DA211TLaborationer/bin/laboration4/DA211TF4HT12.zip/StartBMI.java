package f4;

public class StartBMI {
	public static void main(String[] args) {
		BMI prog = new BMI();
		prog.bmiMethod();
		// prog.bmiMethod();
	}
}
