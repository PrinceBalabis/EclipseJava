package f4;

public class StartPerson2 {
    public static void main(String[] args) {
        Person2 person = new Person2();
        person.presentation();
    }
}
