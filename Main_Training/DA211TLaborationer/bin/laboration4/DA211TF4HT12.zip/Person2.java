package f4;

public class Person2 {
    public void printName() {
        System.out.println("My name is Lisa");
    }

    public void printInformation() {
        System.out.println("I am 9 years old.");
    }

    public void printFamilyName() {
        System.out.println("Bengtsson");
    }

    public void presentation() {
        printName();
        printFamilyName();
        printInformation();
    }
}
