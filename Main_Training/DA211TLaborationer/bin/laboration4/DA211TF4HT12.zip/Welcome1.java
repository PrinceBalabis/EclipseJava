package f4;

public class Welcome1 {
    public void todo() {
        System.out.println("Välkommen till ");
        System.out.println("Java-kurs vid");
        System.out.println("Malmö högskola!");
    }

    public static void main(String[] args) {
        Welcome1 prog = new Welcome1();
        prog.todo();
    }
}
