package f4;

public class StartWelcome1 {
    public static void main(String[] args) {
        Welcome1 prog = new Welcome1();
        prog.todo();
    }
}
