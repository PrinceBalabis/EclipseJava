package f4;

public class StartPerson {
    public static void main(String[] args) {
        Person person = new Person();
        person.printName();
        person.printFamilyName();
    }
}
