﻿package f6;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 * Programmet exemplifierar get-metoden i ett Calendar-objekt
 * @author TSROAX
 */
public class CalendarEx {
    public void example() {
        int dayOfWeek, dayOfMonth, dayOfYear, month;
        String res = "";
        Calendar cal = Calendar.getInstance();
        
        dayOfWeek = cal.get( Calendar.DAY_OF_WEEK );
        dayOfMonth = cal.get( Calendar.DAY_OF_MONTH );
        dayOfYear = cal.get( Calendar.DAY_OF_YEAR );
        month = cal.get( Calendar.MONTH ) + 1;  // Månadsnummer 0-11
        
        res += "Veckodag: " + dayOfWeek + "\nMånadsdag: " + dayOfMonth + "\nÅrsdag: " + dayOfYear + "\nMånadsnummer: " + month;
        JOptionPane.showMessageDialog(null,res); // Visa sträng i en dialog
    }
    
    public static void main(String[] args) {
        CalendarEx prog = new CalendarEx();
        prog.example();
    }
}
