﻿package f6;
import java.util.Random;

/**
 * programmet demonstrar användning av klassen Random
 * @author TSROAX
 */
public class RandomEx {
    public void example() {
        Random randGen = new Random();
        
        System.out.println("Slumpvärde 0-3: " + randGen.nextInt(4));  // 4 slumpvärden
        System.out.println("Slumpvärden 7-10: " + (randGen.nextInt(4) + 7)); // start på 7
        System.out.println("Slumpvärden (-6)-(-3): " + (randGen.nextInt(4) - 6)); // start på -6 
    }
    
    public static void main(String[] args) {
        RandomEx prog = new RandomEx();
        prog.example();
    }
}
