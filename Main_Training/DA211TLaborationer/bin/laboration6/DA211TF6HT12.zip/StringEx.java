﻿package f6;
import javax.swing.JOptionPane;

/**
 * Programmet demonstrar ett par metoder i klassen String
 * @author TSROAX
 */
public class StringEx {
    public void example() {
        char firstChar, lastChar;
        int count, indexOfA;
        String lowerCase, res, str, firstPart, lastPart;
        
        str = JOptionPane.showInputDialog("Skriv lite text, minst 6 tecken");
        
        count = str.length();
        indexOfA = str.indexOf('A');
        firstChar = str.charAt(0);
        lastChar = str.charAt(count-1);
        lowerCase = str.toLowerCase();
        firstPart = str.substring(0, count/2);
        lastPart = str.substring(count/2);
        
        res = "Inamatad text: " + str + "\n" +
              "A finns i positon: " + indexOfA + "\n" +
              "Antal tecken: " + count + "\n" +
              "Första tecknet: " + firstChar + ", sista tecknet: " + lastChar + "\n" +
              "Med små bokstäver: " + lowerCase + "\n" + 
              "Första halvan: \"" + firstPart + "\"\n" +
              "Andra halvan: \"" + lastPart + "\"";
        JOptionPane.showMessageDialog(null,res);
    }
    
    public static void main(String[] args) {
        StringEx prog = new StringEx();
        prog.example();
    }
}
