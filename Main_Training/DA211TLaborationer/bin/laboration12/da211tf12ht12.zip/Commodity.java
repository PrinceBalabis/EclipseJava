/*
 * Commodity.java
 * 5/10-2011
 */

package f12;

/**
 * Klassen representerar en vara i en butik
 * @author Rolf Axelsson
 */
public class Commodity {
    private String name;       // varans namn
    private String category;   // varans avdelning
    private int quantity;      // antal av varan i butiken
    private double price;      // varans pris
    
    public Commodity() {
        this.name = "";
        this.category = "";
    }
    
    public Commodity( String inName, String inCategory, int inQuantity, double inPrice ) {
        this.name = inName;
        this.category = inCategory;
        this.quantity = inQuantity;
        this.price = inPrice;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getCategory() {
        return this.category;
    }
    
    public int getQuantity() {
        return this.quantity;
    }
    
    public double getPrice() {
        return this.price;
    }
    
    public void setName( String inName ) {
        this.name = inName;
    }
    
    public void setCategory( String inCategory ) {
        this.category = inCategory;
    }
    
    public void setQuantity( int inQuantity ) {
        this.quantity = inQuantity;
    }
    
    public void setPrice( double inPrice) {
        this.price = inPrice;
    }
        
    public double value() {
        double total = this.quantity * this.price;
        return total;
    }
    
    public String toString() {
        String res = "Varunamn = " + this.name + "\nKategori = " + this.category +
                "\nAntal = " + this.quantity + "\nPris = " + this.price;
        return res;
    }
}
