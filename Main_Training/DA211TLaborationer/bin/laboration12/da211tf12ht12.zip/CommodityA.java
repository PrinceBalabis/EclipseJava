package f12;

public class CommodityA {
    private String name;
    private String category;
    private int quantity;
    private double price;

	public void setName(String name) {
		this.name = name;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // CommodityEx3
	public String getCategory() {
		return category;
	}

    public String getName() {
		return name;
	}

	public int getQuantity() {
		return quantity;
	}

	public double getPrice() {
		return price;
	}
	
	// CommodityEx1
	public double value() {
	    double totalValue = this.quantity * this.price;
	    return totalValue;
	}

	// CommodityEx2
	public String toString() {
	    String res = "Varunamn = " + this.name + "\nKategori = " + this.category +
	            "\nAntal = " + this.quantity + "\nPris = " + this.price;
        return res;
    }
}
