/*
 * CommodityEx3.java
 * 15/9-2011
 */

package f12;
/**
 * Programmet demonstrerar användning av get-metoder i klassen Commodity.
 * @author Rolf Axelsson
 */
public class CommodityEx3 {
    public void example() {
        Commodity com = new Commodity(); // Ett Commodity-objekt skapas
        // Instansvariablerna tilldelas värde
        com.setName( "Pepparkakor" );
        com.setCategory( "Bageri" );
        com.setQuantity( 90 );
        com.setPrice( 22.50 );

        // Instansvariablernas värde skrivs ut
        System.out.print( "name = " + com.getName() + ", category = " + com.getCategory() );
        System.out.println( ", quantity = " + com.getQuantity() + ", price = " + com.getPrice() );
        System.out.println("Lagervärde av " + com.getName() + ": " + com.value() + " kr" );
    }

    public static void main(String[] args) {
        CommodityEx3 prog = new CommodityEx3();
        prog.example();
    }
}
