package f12;

public class BookEx {
    public void ex() {
        Book book = new Book("Djup", "Henning Mankell", "9173430897");
        book.info();
    }

    public static void main(String[] args) {
        BookEx prog = new BookEx();
        prog.ex();
    }
}
