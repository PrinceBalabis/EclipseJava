package f12;

public class Book {
    private String title;
    private String author = "";
    private String isbn;

    public Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
    }

    public void info() {
        System.out.println("Title: " + this.title + "\nAuthor: " + this.author + "\nISBN: " + this.isbn);
    }
}
