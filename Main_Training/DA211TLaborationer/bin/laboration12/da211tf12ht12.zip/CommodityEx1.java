/*
 * CommodityEx1.java
 * 5/10-2011
 */

package f12;
import javax.swing.*;
/**
 * Programmet demonstrerar anrop av metoden value vilken returnerar varans lagervärde.
 * @author Rolf Axelsson
 */
public class CommodityEx1 {
    public void example() {
        Commodity com = new Commodity();  // Ett Commodity-objekt skapas
        double totalValue;

        com.setName("Häftapparat");
        com.setCategory("Kontor");
        com.setQuantity(30);
        com.setPrice(200.0);

        totalValue = com.value();

        JOptionPane.showMessageDialog( null, "Varans lagervärde är " + totalValue );
    }

    public static void main(String[] args) {
        CommodityEx1 prog = new CommodityEx1();
        prog.example();
    }
}
