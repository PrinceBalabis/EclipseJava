package f12;
import java.util.Random;
import javax.swing.JOptionPane;

public class EstimateTimeVer2 {
    private long getRandomTime() {
        Random rand = new Random();
        return (rand.nextInt(4) + 2)*1000;
    }
    
    private long estimate( long timeToEstimate ) {
        Stopwatch watch = new Stopwatch();
        String txt = "Du ska uppskatta "+(timeToEstimate/1000)+" sekunder.\n\n"+
                "Tryck på OK för att starta tidtagningen.";
        
        JOptionPane.showMessageDialog( null, txt );
        watch.start();
        JOptionPane.showMessageDialog( null, "Tryck på OK för att stoppa tidtagningen" );
        watch.stop();
        
        return watch.getMilliSeconds();
    }
    
    private void showResult( long timeToEstimate, long estimation ) {
        String res = "Uppskattning: " + estimation + "\nFel: " + (estimation - timeToEstimate) + " ms";
        JOptionPane.showMessageDialog( null, res );
        
    }
    
    public void action() {
        long time = getRandomTime();
        long estimation = estimate( time );
        showResult( time, estimation );
    }
    
    public static void main(String[] args) {
        EstimateTimeVer2 prog = new EstimateTimeVer2();
        prog.action();
    }
}
