/*
 * CommodityEx2.java
 * 5/10-2011
 */

package f12;
import javax.swing.*;
/**
 * Programmet demonstrerar anrop av metoderna lagervärde och toString
 * vilka returnerar värde.
 * @author Rolf Axelsson
 */
public class CommodityEx2 {
    public void example() {
        Commodity com = new Commodity();  // Ett Commodity-objekt skapas
        double totalValue;

        com.setName("Häftapparat");
        com.setCategory("Kontor");
        com.setQuantity(30);
        com.setPrice(200.0);

        totalValue = com.value();
        JOptionPane.showMessageDialog( null, com.toString() + "\nLagervärde = " + totalValue );
    }

    public static void main(String[] args) {
        CommodityEx2 prog = new CommodityEx2();
        prog.example();
    }
}
