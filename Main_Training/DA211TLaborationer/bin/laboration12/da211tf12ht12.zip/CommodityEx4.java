/*
 * CommodityEx4.java
 * 5/10-2011
 */

package f12;
import javax.swing.*;
/**
 * Programmet demonstrerar att det går bra att använda olika konstruktorer vid konstruktion av Commodity-objekt. 
 * @author Rolf Axelsson
 */
public class CommodityEx4 {
    public void exempel() {
        Commodity com1 = new Commodity();  // Ett Commodity-objekt skapas
        Commodity com2 = new Commodity("Läkerol", "Godis", 320, 7.90 );  // Ett Commodity-objekt skapas
        
        JOptionPane.showMessageDialog( null, com1.toString() );
        JOptionPane.showMessageDialog( null, com2.toString() );
    }

    public static void main(String[] args) {
        CommodityEx4 prog = new CommodityEx4();
        prog.exempel();
    }
}
