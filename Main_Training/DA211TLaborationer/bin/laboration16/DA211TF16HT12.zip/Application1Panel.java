package f16;
import java.awt.*; // Color, Dimension

import javax.swing.JPanel;

public class Application1Panel extends JPanel {
    public Application1Panel() {
        setBackground( Color.red );
        setPreferredSize( new Dimension(300,200) );
    }
}
